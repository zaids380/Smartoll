<html>
<body>
<form method = "post" action="test.php">
<input type="text" name="search"><br>
<input type="submit" name="submit">
</form>
</body>
</html>