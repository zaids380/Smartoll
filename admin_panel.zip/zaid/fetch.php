<?php require_once 'navbar.php';
 ?>

<!DOCTYPE HTML>
<html>
<link rel="stylesheet" href="custom.css">

	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="bootstrap/css/bootstrap-theme.min.css">
	
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script src="bootstrap/js/bootstrap.min.js"></script>
	
    <body>
	 <div class="table-responsive">
						<table  class="table  table-striped table-bordered table-hover ">
						
<?php
        $connect = mysqli_connect("localhost", "root", "", "smartoll");
        $output = '';
        if(isset($_POST["query"]))
        {
            $search = mysqli_real_escape_string($connect, $_POST["query"]);
            $query = "
            SELECT * FROM detail 
            WHERE id LIKE'%".$search."%'
            OR user LIKE '%".$search."%'
            OR password LIKE '%".$search."%'
            OR aadhar LIKE '%".$search."%' 
              OR qrcode LIKE '%".$search."%' 
              OR pay_date LIKE '%".$search."%'
			  OR leave_date LIKE '%".$search."%'";
        }
        else
{
 $query = "
  SELECT * FROM detail";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
 $output .= '
    <tr>
     <th>ID</th>
     <th>USER</th>
     <th>PASSWORD</th>
     <th>AADHAR</th>
     <th>QRCODE</th>
	 <th>PAYDATE</th>
	 <th>LEAVE_DATE</th>
    </tr>
 ';
 while($row = mysqli_fetch_array($result))
 {
  $output .= '
   <tr>
    <td>'.$row["id"].'</td>
    <td>'.$row["user"].'</td>
    <td>'.$row["password"].'</td>
    <td>'.$row["aadhar"].'</td>
    <td>'.$row["qrcode"].'</td>
	<td>'.$row["pay_date"].'</td>
	<td>'.$row["leave_date"].'</td>
   </tr>
  ';
 }
 echo $output;
}
else
{
 echo 'Data Not Found';
}

?>
            </table>
    
    </body>
</html>