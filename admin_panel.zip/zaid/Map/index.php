<?php

include "class.phpmailer.php";
include "class.smtp.php";



$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
try {
    //Server settings
    $mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'zaids380@gmail.com';                 // SMTP username
    $mail->Password = '844990150';                           // SMTP password
    $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 586;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('zaids380@gmail', 'zaid');
    $mail->addAddress('zaidkhn222@gmai.com', 'Abdul Mabood');     // Add a recipient
    //$mail->addAddress('jisko send krna h uska email yaha pe rahega');               // Name is optional
    //$mail->addReplyTo('shdkhan1997@gmail.com', 'Shahid Khan');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');

    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'phpmailer';
    $mail->Body    = 'Quddus bhai mail send ho gya h';
    $mail->AltBody = 'Masuri khan mail send ho gya h hahaha';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
}
