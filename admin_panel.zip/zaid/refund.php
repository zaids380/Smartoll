<?php
require 'connection.php';
$usrname=$_POST['username'];
$psswrd=$_POST['password'];
$query="SELECT status FROM users WHERE username='$usrname' AND password='$psswrd'";
$res=$connect->query($query);
$row=mysqli_fetch_assoc($res);
if($row['status']==1)
{
	$select="SELECT refundable FROM `wallet` WHERE username='$usrname' And password='$psswrd'";
	$result=$connect->query($select);
	$row=mysqli_fetch_assoc($result);
	$a=$row['refundable'];
	echo $row['refundable'];
	$slct="SELECT wallet FROM `wallet` WHERE username='$usrname' And password='$psswrd'";
	$rslt=$connect->query($slct);
	$row=mysqli_fetch_assoc($rslt);
	
	$b=$row['wallet'];
	$c=$a+$b;
	$updt="UPDATE wallet SET `wallet`=$c WHERE username='$usrname' And password='$psswrd'";
	$rs=$connect->query($updt);
	
	$sql="UPDATE `users` SET `status`=0 WHERE username='$usrname' And password='$psswrd'";
	$result=$connect->query($sql);
	$s="UPDATE `wallet` SET `refundable`=0 WHERE username='$usrname' And password='$psswrd'";
	$r=$connect->query($s);
 }
else
{
	echo "no";
}

?>