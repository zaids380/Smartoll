<?php require_once 'navbar.php';
	require_once 'connection.php'
 ?>
<?php
if(isset($_POST['search']))
{
		$var = $_POST['search_value'];

		$sql = "SELECT * FROM `users` WHERE CONCAT(username,QRvalue,aadhar,email,status,password) LIKE '%$var%'";
		$res = mysqli_query($connect,$sql);
}
else
{
	$sql="SELECT * FROM `users`";
	$res = mysqli_query($connect,$sql);
}
?>
<html>
<head>

<link rel="stylesheet" href="custom.css">

	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="bootstrap/css/bootstrap-theme.min.css">
	
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script src="bootstrap/js/bootstrap.min.js"></script>
	
  	 <title>SMARTOLL DETAILS</title>

</head>
	<body>
	
	<h1 id= "head1">SMARTOLL </h1>
<div class="marquee">
<h3 id= "scroll">Toll System Using QRcode <img src="smartoll logo.png"  height="65" width="80"></h3>
</div>

			
			<div class="container">
			<table>	
				<div class="row">
				<form class="form-horizontal" action="home.php" " method="post" id="loginForm">
				 <div class="form-group">
									<!--<label for="search" id="search"class="col-sm-2 control-label"> Search</label>-->
									<div class="col-sm-4">
									  <input type="text" class="form-control" id="username" name="search_value" placeholder="Search" autocomplete="off" />
									</div>
									
									<div class="form-group">
									<div class="col-sm-offset-2 col-sm-10">
									  <button type="submit" class="btn btn-primary" name ="search"id="bbtn" > <i class="glyphicon glyphicon-search"></i> Search</button>
									</div>
						</form>
					<div class="table-responsive">
						<table  class="table  table-striped table-bordered table-hover ">
						
					  <tr class="info">
					    <th>username</th>
						<th>car number</th>
					    <th>password</th>
						<th>aadhar</th>
						<th>QRcode</th>
						<th>status</th>
						<th>email</th>
					  </tr>
					<?php while ($row=mysqli_fetch_array($res)):?>
					  <tr>
					    <td><?php echo $row['username'];?> </td> 
					    <td><?php echo $row['car number'];?> </td>
						<td><?php echo $row['password'];?> </td>
	

	<td><?php echo $row['aadhar'];?> </td>
						<td><?php echo $row['QRvalue'];?> </td>
						<td><?php echo $row['status'];?> </td>
						<td><?php echo $row['email'];?> </td>
						<?php endwhile;?>
						</tr>
						
						
						
						

			</table>
		</table>
	</div>
	</div>
	</div>
	</div>


</body>

</html>