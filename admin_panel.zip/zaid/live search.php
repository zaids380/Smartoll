<?php require_once 'navbar.php';
	require_once 'connection.php'
 ?>
<?php
if(isset($_POST['search']))
{
		$var = $_POST['search_value'];
	
		$sql = "SELECT * FROM `detail` WHERE CONCAT(id,user,password,aadhar,pay_date,leave_date) LIKE '%$var%'";
		$res = mysqli_query($connect,$sql);
}
else
{
	$sql="SELECT * FROM `detail`";
	$res = mysqli_query($connect,$sql);
}
?>