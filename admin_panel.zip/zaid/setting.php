<?php require_once 'navbar.php'; ?>
<html>
<head>
<title>SMARTOLL LOGIN</title>

</head>
<body>
<h1 id= "head1">SMARTOLL </h1>
<div class="marquee">
<h3 id= "scroll">Toll System Using QRcode <img src="smartoll logo.png"  height="65" width="80"></h3>
</div>


<link rel="stylesheet" href="custom.css">
</body>
</html>