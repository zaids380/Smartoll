<?php
require 'connection.php';
$usrname=$_POST['username'];
$psswrd=$_POST['password'];
$email=$_POST['email'];
$amnt=$_POST['amount'];
$sql2="SELECT wallet FROM `wallet` WHERE username='$usrname' AND password='$psswrd'";
$amount=0;
$result=$connect->query($sql2);
if($result->num_rows > 0)
{
	while($row=$result->fetch_assoc())
	{
		$amount= $row['wallet'];
	}
	$amnt=$amnt+$amount;
   $sql=" UPDATE `wallet` SET wallet='$amnt' WHERE username='$usrname' AND password='$psswrd'";
	$result=$connect->query($sql);
	if($result)
	{
		echo $amnt;
	}
}


?>