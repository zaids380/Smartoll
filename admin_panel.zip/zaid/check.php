<?php
require 'connection.php';
$Usrname=$_POST["username"];
$carnumbr=$_POST["car_number"];
$pass=$_POST["password"];
$adhar=$_POST["aadhar"];
$email=$_POST["email"];
$qr=$adhar.$carnumbr;
$qrcode=md5($qr).rand(1,999);
$status="0";
$am="0";
$rf="0";
$mysql_qry="INSERT INTO `users`(`username`, `car number`, `password`, `aadhar`,`email`, `QRvalue`, `status`)
VALUES ('$Usrname','$carnumbr','$pass','$adhar','$email','$qrcode','$status')";
$result = $connect->query($mysql_qry);
if($result)
{
	$query="INSERT INTO `wallet`( `username`, `password`, `email`, `wallet`, `refundable`) VALUES ('$Usrname','$pass','$email','$am','$rf')";
	$res=$connect->query($query);
	echo "successfully Registered";
}
else
{
	echo "something went wrong!!!";
}
?>