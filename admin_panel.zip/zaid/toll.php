<?php
require 'connection.php';
$src=$_POST["src"];
$dest=$_POST["dest"];
$vid=$_POST["vid"];
$sql="SELECT toll_id FROM toll_detail WHERE source LIKE '$src' and destination like '$dest' or source LIKE '$dest' and destination like '$src'";
$result=$connect->query($sql);
$id=0;
$tolls=array();
if($result->num_rows > 0)
{
	while($row=$result->fetch_assoc())
	{
		$id=$row['toll_id'];	
	}
}
else
{
	echo "toll id not found";
}

$sql2="SELECT `toll_name`,`price` FROM `toll` WHERE toll_id LIKE '$id' AND v_id LIKE '$vid'";
$stmt=$connect->prepare($sql2);
$stmt->execute();
$stmt->bind_result($toll_name,$price);
while($stmt->fetch()){
 
 //pushing fetched data in an array 
 $temp = [
 'tollname'=>$toll_name,
 'price'=>$price
 
 
 ];
array_push($tolls, $temp);
}
echo json_encode($tolls);
?>