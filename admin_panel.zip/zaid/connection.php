<?php 
$localhost = "localhost";
$username = "root";
$password = "";
$dbname = "smartoll";
$connect= new mysqli($localhost, $username, $password, $dbname);
?>