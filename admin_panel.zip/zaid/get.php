<?php
require 'connection.php';
$usrname=$_POST['username'];
$psswrd=$_POST['password'];
$sql2="SELECT wallet FROM `wallet` WHERE username='$usrname' AND password='$psswrd'";
$result=$connect->query($sql2);
$row=mysqli_fetch_assoc($result);
echo $row['wallet'];
?>