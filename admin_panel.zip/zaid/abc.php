<?php
require 'connection.php';
$value=$_POST['one'];
$col_value=trim($value,"[']");
$sql1 = "SELECT * FROM users WHERE QRvalue = '$col_value'";
$res1 = mysqli_query($connect,$sql1);
$count1 = mysqli_num_rows($res1);
//if($count1 == 1)

$row1 = mysqli_fetch_assoc($res1);
if($row1['status'] == 1)
{
	$sql="UPDATE `users` SET `status`=0 WHERE QRvalue = '$col_value'";
	$result=$connect->query($sql);
	if($result)
		echo "1";
	$sql2="UPDATE `detail` SET `leave_date`=Now()WHERE qrcode='$col_value'";
	$ress=$connect->query($sql2);
}
else if ($row1['status'] == 0)
{
	echo "0";
}

?>

