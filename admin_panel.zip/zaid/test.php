<html>
<body>
<form method = "post" action="test.php">
<input type="text" name="search"><br>
<input type="submit" name="submit">
</form>
</body>
</html>
<?php
include "connection.php";
if(isset($_POST['submit']))
{
		$var = $_POST['search'];

		$sql = "SELECT * FROM `list` WHERE CONCAT(name,v_type,v_no,mobile,status) LIKE '%$var%'";
		$res = mysqli_query($connect,$sql);
		$count = mysqli_num_rows($res);
		echo $count;
		for($i=0;$i< $count;$i++)
		{
			$row=mysqli_fetch_assoc($res);
			echo $row['name'];
			}
		
}		
		
?>