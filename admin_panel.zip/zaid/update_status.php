<?php
require 'connection.php';
$usrname=$_POST['username'];
$psswrd=$_POST['password'];
$amnt=$_POST['amount'];
$qr;
$deduct;
$update="UPDATE`wallet` SET refundable='$amnt' WHERE username='$usrname' AND password='$psswrd'";
$r=$connect->query($update); 
$sqll="SELECT wallet FROM `wallet` WHERE username='$usrname' And password='$psswrd'";
$rslt=$connect->query($sqll);
while ($row=mysqli_fetch_assoc($rslt))
{
  $deduct= $row['wallet'];
}

if($deduct>$amnt)
{
$new=$deduct-$amnt;
$update="UPDATE `wallet` SET `wallet`='$new' WHERE username='$usrname' AND password='$psswrd'";
$update_result=$connect->query($update);
}




$sql="UPDATE `users` SET `status`=1 WHERE username='$usrname' AND password='$psswrd'";
$result=$connect->query($sql);

$query="SELECT aadhar FROM users WHERE username='$usrname' AND password='$psswrd'";
$res=$connect->query($query);
$aadhar;
while ($row=mysqli_fetch_assoc($res))
{
	$aadhar=$row['aadhar'];
	
}


if($result)
{
	$select="SELECT `QRvalue` FROM `users` WHERE username='$usrname' AND password='$psswrd'";
	
	
	$res=$connect->query($select);
		while($row=mysqli_fetch_assoc($res))
		{
			$qr=$row['QRvalue'];
		
		}
		echo $qr;
	$insert="INSERT INTO `detail`(`user`, `password`,`aadhar`,`qrcode`,`pay_date`) 
	VALUES ('$usrname','$psswrd','$aadhar','$qr',Now())";
	$res=$connect->query($insert);
}
else
{
	echo 0;
}
?>