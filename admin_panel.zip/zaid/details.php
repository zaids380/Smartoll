<html>
    <head>
	<h1 id= "head1">SMARTOLL </h1>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>details</title>
		<link rel="stylesheet" href="custom.css">
			<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="bootstrap/css/bootstrap-theme.min.css">
	
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script src="bootstrap/js/bootstrap.min.js"></script>
	
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        
    </head>
    <body>
       <div class="container">
			<table>	
				<div class="row">
				<form class="form-horizontal"id="loginForm">
				 <div class="form-group">
							
									<div class="col-sm-4">
									  <input type="text" class="form-control" id="search_text" name="search_text" placeholder="Search" autocomplete="off" />
									</div>
						</form>
						</div>
					</table>
        <div id="result"></div>
        </div>
    </body>
	</div>
</html>


<script>
$(document).ready(function(){

 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
    $('#result').html(data);
   }
  });
 }
 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});
</script>