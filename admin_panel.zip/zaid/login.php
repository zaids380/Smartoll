<?php
require 'connection.php';
$user_name=$_POST["username"];
$password=$_POST["password"];
$sql="SELECT * FROM `users` WHERE username LIKE '$user_name' AND password LIKE '$password'";
$result=$connect->query($sql);
if(mysqli_num_rows($result)>0)
{
	echo"login success";
}
else
{
	echo "login fail";
}


?>